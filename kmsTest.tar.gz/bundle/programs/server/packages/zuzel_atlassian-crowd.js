(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;

/* Package-scope variables */
var AtlassianCrowd, ATLASSIAN_CROWD_CONFIG;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/zuzel_atlassian-crowd/packages/zuzel_atlassian-crowd.js                              //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
(function () {                                                                                   // 1
                                                                                                 // 2
/////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                         //    // 4
// packages/zuzel:atlassian-crowd/server/crowd_server.js                                   //    // 5
//                                                                                         //    // 6
/////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                           //    // 8
AtlassianCrowd = Npm.require('atlassian-crowd');                                           // 1  // 9
var Future = Npm.require('fibers/future');                                                 // 2  // 10
ATLASSIAN_CROWD_CONFIG = {};                                                               // 3  // 11
var instance = null;                                                                       // 4  // 12
AtlassianCrowd.instance = function(){                                                      // 5  // 13
    if(!instance){                                                                         // 6  // 14
        instance = new AtlassianCrowd(ATLASSIAN_CROWD_CONFIG);                             // 7  // 15
    }                                                                                      // 8  // 16
    return instance;                                                                       // 9  // 17
}                                                                                          // 10
                                                                                           // 11
var loginWithAtlassianCrowdSync = function (username, password) {                          // 12
    if (!ATLASSIAN_CROWD_CONFIG.crowd || !ATLASSIAN_CROWD_CONFIG.crowd.base) {             // 13
        throw new Meteor.Error("Malformed config", "crowd.base is not defined");           // 14
    }                                                                                      // 15
    if (!ATLASSIAN_CROWD_CONFIG.application.name) {                                        // 16
        throw new Meteor.Error("Malformed config", "application.name is not defined");     // 17
    }                                                                                      // 18
    if (!ATLASSIAN_CROWD_CONFIG.application.password) {                                    // 19
        throw new Meteor.Error("Malformed config", "application.password is not defined"); // 20
    }                                                                                      // 21
                                                                                           // 22
    var syncFuture = new Future();                                                         // 23
    AtlassianCrowd.instance().user.authenticate(username, password, function (err, res) {  // 24
            syncFuture.return({                                                            // 25
                error: err ? err.message : null,                                           // 26
                success: res                                                               // 27
            });                                                                            // 28
    });                                                                                    // 29
                                                                                           // 30
    return syncFuture.wait();                                                              // 31
}                                                                                          // 32
                                                                                           // 33
Accounts.registerLoginHandler("atlassianCrowd", function (loginRequest) {                  // 34
    if (!loginRequest.atlassianCrowdAuth) {                                                // 35
        return undefined;                                                                  // 36
    }                                                                                      // 37
    var u = loginRequest.atlassianCrowdAuth.crowdUsername;                                 // 38
    var p = loginRequest.atlassianCrowdAuth.crowdUserPassword;                             // 39
                                                                                           // 40
    var result = loginWithAtlassianCrowdSync(u, p);                                        // 41
                                                                                           // 42
    if (result.error) {                                                                    // 43
        throw new Meteor.Error("Invalid credentials", result.error);                       // 44
    } else {                                                                               // 45
        var res = result.success;                                                          // 46
        var userId = null;                                                                 // 47
        var stampedToken = {                                                               // 48
            token: null                                                                    // 49
        };                                                                                 // 50
        var username = res.name;                                                           // 51
        if (!res.active) {                                                                 // 52
            throw new Meteor.Error("Not Active", "User exists but is not active");         // 53
        }                                                                                  // 54
        // Look to see if user already exists                                              // 55
        var user = Meteor.users.findOne({                                                  // 56
            username: username                                                             // 57
        });                                                                                // 58
        if (user) {                                                                        // 59
            // Set initial userId and token vals                                           // 60
            userId = user._id;                                                             // 61
                                                                                           // 62
            // Create hashed token so user stays logged in                                 // 63
            stampedToken = Accounts._generateStampedLoginToken();                          // 64
            var hashStampedToken = Accounts._hashStampedToken(stampedToken);               // 65
            // Update the user's token in mongo                                            // 66
            Meteor.users.update(userId, {                                                  // 67
                $push: {                                                                   // 68
                    'services.resume.loginTokens': hashStampedToken                        // 69
                }                                                                          // 70
            });                                                                            // 71
        } else {                                                                           // 72
            var userObject = {                                                             // 73
                username: username,                                                        // 74
                profile: {}                                                                // 75
            };                                                                             // 76
            // Set email                                                                   // 77
            if (res.email) userObject.email = res.email;                                   // 78
            if (res['display-name']) {                                                     // 79
                userObject.profile.displayName = res['display-name'];                      // 80
            }                                                                              // 81
                                                                                           // 82
            userId = Accounts.createUser(userObject);                                      // 83
        }                                                                                  // 84
        return {                                                                           // 85
            userId: userId,                                                                // 86
            token: stampedToken.token                                                      // 87
        };                                                                                 // 88
    }                                                                                      // 89
});                                                                                        // 90
                                                                                           // 91
                                                                                           // 92
/////////////////////////////////////////////////////////////////////////////////////////////    // 101
                                                                                                 // 102
}).call(this);                                                                                   // 103
                                                                                                 // 104
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zuzel:atlassian-crowd'] = {
  AtlassianCrowd: AtlassianCrowd,
  ATLASSIAN_CROWD_CONFIG: ATLASSIAN_CROWD_CONFIG
};

})();

//# sourceMappingURL=zuzel_atlassian-crowd.js.map
