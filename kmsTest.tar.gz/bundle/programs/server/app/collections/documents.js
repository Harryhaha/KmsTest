(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/documents.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by DELL on 2015/12/8.                                       //
 */                                                                    //
//var kms = new MongoInternals.RemoteCollectionDriver("mongodb://kms:kms@dev02.pek.cclaw.net:27017/kms");
//Pages = new Mongo.Collection('pages', { _driver: kms });             //
                                                                       //
Pages = new Mongo.Collection('pages');                                 // 7
Segments = new Mongo.Collection('segments');                           // 8
Paragraphs = new Mongo.Collection('paragraphs');                       // 9
Phrases = new Mongo.Collection('phrases');                             // 10
                                                                       //
Meteor.methods({                                                       // 13
    getAllCookies: function (url) {                                    // 14
        if (Meteor.isServer) {                                         // 15
            var toughCookie = Meteor.npmRequire('tough-cookie');       // 16
            var cookieJar = new toughCookie.CookieJar();               // 17
            //cookieJar.getCookies(url, function(err, cookies){        //
                                                                       //
            cookieJar.setCookie('test=HVAXZ2JKXvbAvVGrjFZnxg00;path=/;domain=cclaw.net', url, function (err, cookies) {
                if (err) {                                             // 21
                    return err;                                        // 22
                } else {                                               //
                    console.log(cookies);                              // 25
                    return cookies;                                    // 26
                }                                                      //
            });                                                        //
                                                                       //
            //cookieJar.setCookieSync('test=HVAXZ2JKXvbAvVGrjFZnxg00;path=/;domain=cclaw.net', "http://beta.cclaw.net/");
        }                                                              //
    },                                                                 //
                                                                       //
    createSession: function (username, password) {                     // 36
        if (Meteor.isServer) {                                         // 37
            AtlassianCrowd.instance().session.create(username, password, function (err, token) {
                if (err) {                                             // 39
                    return err;                                        // 40
                } else {                                               //
                    console.log(token);                                // 43
                    AtlassianCrowd.instance().session.authenticate(token, function (err, res) {
                        if (err) {                                     // 45
                            return err;                                // 46
                        } else {                                       //
                            console.log(res);                          // 49
                            return res;                                // 50
                        }                                              //
                    });                                                //
                }                                                      //
            });                                                        //
        }                                                              //
    },                                                                 //
                                                                       //
    headers: function () {                                             // 58
        if (Meteor.isServer) {                                         // 59
            var header = headers.get(this);                            // 60
            var cookieToken = header.cookie;                           // 61
            var token = cookieToken.split('=');                        // 62
            return token[1];                                           // 63
        }                                                              //
    },                                                                 //
                                                                       //
    authentification: function (token, option) {                       // 67
        if (Meteor.isServer) {                                         // 68
            Future = Npm.require('fibers/future');                     // 69
            var myFuture = new Future();                               // 70
            AtlassianCrowd.instance().session.authenticate(token, option, function (err, res) {
                if (err) {                                             // 72
                    console.log(err);                                  // 73
                    //return err;                                      //
                    myFuture['throw'](err);                            // 75
                } else {                                               //
                    console.log(res);                                  // 78
                    //return res;                                      //
                    myFuture['return'](res.token);                     // 80
                }                                                      //
            });                                                        //
                                                                       //
            return myFuture.wait();                                    // 84
        }                                                              //
    }                                                                  //
                                                                       //
});                                                                    //
                                                                       //
//AtlassianCrowd.instance().session.authenticate(token, function (err, res) {
//    if (err) {                                                       //
//        throw err;                                                   //
//    }                                                                //
//    else {                                                           //
//        console.log(res);                                            //
//    }                                                                //
//})                                                                   //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=documents.js.map
