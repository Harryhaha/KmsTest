(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by DELL on 2015/12/8.                                       //
 */                                                                    //
Meteor.startup(function () {                                           // 4
    ATLASSIAN_CROWD_CONFIG.crowd = {                                   // 5
        "base": "https://login.cclaw.net/crowd/"                       // 6
    };                                                                 //
    ATLASSIAN_CROWD_CONFIG.application = {                             // 8
        "name": "meteor",                                              // 9
        "password": "crowd123"                                         // 10
    };                                                                 //
                                                                       //
    // https://atmospherejs.com/zuzel/atlassian-crowd                  //
    /* test the connection                                             //
    AtlassianCrowd.instance().ping(function (err, res) {               //
        if(err) {                                                      //
            throw err;                                                 //
        }                                                              //
        else {                                                         //
            console.log(res)                                           //
        }                                                              //
    });                                                                //
    */                                                                 //
    /* return all of the user's attributes on the crowd                //
    AtlassianCrowd.instance().user.attributes('ariunaa', function (err, res) {
        if(err) {                                                      //
            throw err;                                                 //
        }                                                              //
        else {                                                         //
            console.log(res);                                          //
        }                                                              //
    });                                                                //
    */                                                                 //
                                                                       //
    /* List a Users Group Membership                                   //
    AtlassianCrowd.instance().user.groups('ariunaa', function (err, res) {
        if(err) {                                                      //
            throw err;                                                 //
        }                                                              //
        else {                                                         //
             AtlassianCrowd.instance().groups.find(res, function (err, res) {
                 if(err) {                                             //
                     throw err;                                        //
                 }                                                     //
                 else {                                                //
                     console.log(res);                                 //
                 }                                                     //
             });                                                       //
            //console.log(res);                                        //
        }                                                              //
    });                                                                //
    */                                                                 //
                                                                       //
    //AtlassianCrowd.instance().session.create("ariunaa", "Adrian2010", function (err, token) {
    //    if(err) {                                                    //
    //        throw err;                                               //
    //    }                                                            //
    //    else {                                                       //
    //        AtlassianCrowd.instance().session.authenticate(token, function (err, res) {
    //            if(err) {                                            //
    //                throw err;                                       //
    //            }                                                    //
    //            else {                                               //
    //                console.log(res);                                //
    //            }                                                    //
    //        });                                                      //
    //    }                                                            //
    //});                                                              //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures.js.map
