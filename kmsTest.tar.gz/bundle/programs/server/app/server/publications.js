(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by DELL on 2015/12/8.                                       //
 */                                                                    //
//correspond to documentsList router template                          //
Meteor.publish('pages', function () {                                  // 5
    return Pages.find({ kmsTitle: "Home" });                           // 6
});                                                                    //
Meteor.publish('segments', function () {                               // 8
    return Segments.find({ kmsTitle: "PgSegments" }); // only publish the segments on whole document level
});                                                                    //
                                                                       //
//                                                                     //
Meteor.publish('singleDocument', function (segmentId) {                // 13
    return Segments.find({ _id: segmentId });                          // 14
});                                                                    //
Meteor.publish('allParagraphsBelongToSegment', function (PgID) {       // 16
    //PgID is the id of the segment include this paragraph             //
    return Paragraphs.find({ PgID: PgID }); //get all of the paragraphs belong to specific segment
});                                                                    //
Meteor.publish('allPhrases', function () {                             // 19
    return Phrases.find({});                                           // 20
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
